# ARI.S

Asset Reconfiguration and Integration System - A modern desktop application for Unreal Engine modding, providing tools for managing Retoc and UAsset operations.

## Features

### Retoc Manager
- **Pak Legacy Assets (Legacy → Zen)**: Convert edited legacy assets (.uasset/.uexp) into Zen format (.utoc/.ucas/.pak)
- **Unpak Game Files (Zen → Legacy)**: Extract game assets from Zen paks to legacy layout for inspection and editing
- Auto-detection of Unreal Engine versions
- Configurable output paths and options
- Real-time console output

### UAsset Manager
- **Export to JSON**: Convert .uasset/.uexp files to JSON format for editing
- **Import from JSON**: Convert JSON files back to .uasset/.uexp format
- File counting and progress tracking
- Batch processing support

### Modern UI
- Dark theme with blue accent colors
- Sidebar navigation with smooth transitions
- Card-based home screen
- Responsive design
- Drag-and-drop support for .pak files

## Requirements

- Windows 10/11
- Go 1.23+
- .NET 8.0 (for UAssetBridge)
- Wails v3+

## Installation

1. Clone or download the project
2. Ensure you have the required dependencies installed
3. Build the application:
   ```bash
   wails build
   ```

## Usage

### First Time Setup

1. Launch ARI.S
2. Go to Settings and configure paths:
   - Set the path to `retoc.exe`
   - Set the path to `uasset_bridge.exe`
3. Configure your preferred Unreal Engine version

### Retoc Manager

#### Converting Legacy to Zen (Building Mods)
1. Select "Retoc Manager" from the sidebar
2. Set your input mod folder (containing edited .uasset/.uexp files)
3. Set your output directory
4. Configure optional settings (output name, order suffix, priority)
5. Click "Run" to execute the conversion

#### Extracting Zen to Legacy
1. Set your game paks folder (usually in Steam/Xbox game directory)
2. Set your extract output directory
3. Optionally specify a subfolder name
4. Click "Run" to extract assets

### UAsset Manager

#### Exporting to JSON
1. Select "UAsset Manager" from the sidebar
2. Choose a folder containing .uasset/.uexp files
3. Click "Export to JSON" to convert files

#### Importing from JSON
1. Choose a folder containing .json files
2. Click "Import from JSON" to convert back to .uasset/.uexp

## File Structure

```
ARI-S/
├── build/                    # Build output directory
│   ├── retoc.exe            # Retoc executable
│   ├── uasset_bridge.exe    # UAsset bridge executable
│   └── oo2core_9_win64.dll  # Required DLL for retoc
├── frontend/                 # Frontend files
│   ├── index.html           # Main HTML
│   ├── main.js              # JavaScript functionality
│   └── public/
│       └── style.css        # Modern dark theme CSS
├── UAssetBridge/            # .NET console application
│   └── UAssetBridge/        # C# source code
├── app.go                   # Main application struct
├── config.go                # Configuration management
├── retoc.go                 # Retoc service
├── uasset.go                # UAsset service
└── main.go                  # Application entry point
```

## Configuration

Settings are automatically saved to:
`%USERPROFILE%\AppData\Local\ARI-S\config.json`

The configuration includes:
- Last used paths for all operations
- Preferred Unreal Engine version
- Application preferences

## Development

### Building from Source

1. Install dependencies:
   ```bash
   go mod tidy
   ```

2. Build the UAssetBridge:
   ```bash
   cd UAssetBridge/UAssetBridge
   dotnet publish -c Release -r win-x64 --self-contained true -o ../../build
   ```

3. Run in development mode:
   ```bash
   wails dev
   ```

4. Build for production:
   ```bash
   wails build
   ```

### Adding New Features

The application is designed to be modular. To add new tool panes:

1. Create a new service in Go (similar to `retoc.go` and `uasset.go`)
2. Add the service to the main application
3. Create a new pane in the frontend HTML
4. Add navigation and functionality in JavaScript

## Troubleshooting

### Common Issues

1. **retoc.exe not found**: Ensure retoc.exe is in the build directory or configure the correct path in settings
2. **UAssetBridge not working**: The current implementation is a placeholder. Full UAssetAPI integration requires building the library from source
3. **Permission errors**: Run as administrator if you encounter file access issues

### Logs

Application logs are displayed in the output console within each pane. Check the console for detailed error messages.

## Contributing

This is a development project. Contributions and improvements are welcome!

## License

This project is for educational and modding purposes. Please respect the terms of service of the games you're modding.