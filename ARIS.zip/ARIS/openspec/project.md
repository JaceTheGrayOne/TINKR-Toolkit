# Project Context

## Purpose

**ARI.S** (Asset Reconfiguration and Integration System) is a Windows desktop application designed to streamline Unreal Engine modding workflows, specifically for Grounded 2. The toolkit wraps complex command-line tools (Retoc for IoStore operations and UAssetAPI for asset conversions) into a modern, user-friendly GUI.

**Goals:**
- Provide a single, cohesive interface for common modding operations
- Eliminate the need to memorize complex CLI arguments
- Persist user preferences and last-used paths for efficiency
- Enable both mod creators (packing legacy assets to Zen format) and mod inspectors (unpacking game files)

## Tech Stack

### Backend
- **Go 1.24+** - Main application logic
- **Wails v3.0.0-alpha.36** - Desktop application framework (Go + web UI)
- **.NET 9.0** - UAssetBridge console application for UAsset/JSON conversion

### Frontend
- **Vanilla JavaScript** - No framework, uses Wails Go bindings
- **Vite** - Build tool and bundler (configured via Wails)
- **HTML/CSS** - Single-page application with custom dark/light themes

### External Tools (Bundled)
- **Retoc** - Unreal Engine IoStore CLI tool for packing/unpacking .utoc/.ucas/.pak files
- **oo2core_9_win64.dll** - Required compression library for Retoc
- **UAssetBridge** - Custom .NET wrapper (placeholder for UAssetAPI integration)

### Development Tools
- **Task (go-task)** - Build automation via Taskfile.yml
- **Build scripts** - build.bat for comprehensive Windows builds

## Project Conventions

### Code Style

#### Go
- **Standard formatting**: Use `go fmt` for all Go files
- **Naming**:
  - Services: `XxxService` struct with `NewXxxService(app *App)` constructor
  - Methods: PascalCase for exported methods (callable from frontend)
  - Private methods: camelCase
- **Error handling**: Always return structured result types (e.g., `RetocResult`, `UAssetResult`) with `Success bool`, `Message string`, `Error string` fields
- **Context**: All service methods take `context.Context` as first parameter
- **Configuration**: Use JSON for persistence, stored in `%APPDATA%\Local\ARI-S\config.json`

#### C# (UAssetBridge)
- **Standard C# conventions**: PascalCase for public members
- **Console output**: Use descriptive progress messages (e.g., "Processed X/Y files")
- **Error handling**: Use try-catch with user-friendly console error messages
- **Self-contained**: Build with `--self-contained true` to avoid .NET runtime dependencies

#### JavaScript
- **Naming**: camelCase for variables and functions
- **Wails bindings**: Import from auto-generated `bindings/` directory
- **DOM manipulation**: Use vanilla JS (querySelector, addEventListener)
- **No frameworks**: Keep frontend lightweight and dependency-free

#### CSS
- **Theming**: Support both dark (default) and light modes via CSS variables
- **Layout**: Use flexbox for responsive layouts
- **Gradients**: Dynamic gradients for "gamer aesthetic" (blue/gray/black palette)
- **Animations**: Smooth transitions for theme switching and hover effects

### Architecture Patterns

#### Service-Oriented Backend
- **Main App** (`app.go`): Handles lifecycle (WailsInit, WailsShutdown), configuration, and Windows folder dialogs
- **Specialized Services**: Each external tool gets its own service (RetocService, UAssetService)
- **Service Registration**: All services registered in `main.go` via `application.NewService()`
- **Separation of Concerns**: Services don't call each other; they're independent

#### Command Execution Pattern
All external tool execution follows this pattern:
1. Validate paths and inputs
2. Build command arguments as string slice
3. Use `exec.CommandContext(ctx, exe, args...)` with timeout support
4. Set working directory to tool's directory (for DLL dependencies)
5. Capture combined output (stdout + stderr)
6. Return structured result with success/failure, output, error, and duration

#### Configuration Pattern
- **Lazy initialization**: Maps created on first use
- **Automatic persistence**: Load on WailsInit, save on WailsShutdown
- **Path memory**: Store last-used paths keyed by field name (e.g., "input_mod_folder")
- **Preferences**: Theme, UE version, tool paths

#### Frontend Communication
- **Wails bindings**: Auto-generated TypeScript-style bindings in `frontend/bindings/`
- **Async/await**: All Go methods return Promises in JavaScript
- **Real-time output**: Console areas updated during long operations
- **Error display**: User-friendly notifications for failures

### Testing Strategy

**Current State**: No automated tests implemented yet.

**Future Strategy** (when adding tests):
- **Go tests**: Use `testing` package for service logic, especially command construction
- **Integration tests**: Test Retoc/UAssetBridge integration with sample files
- **Frontend**: Manual testing in dev mode (`wails3 dev`)
- **Build verification**: Use `test_functionality.bat` for smoke testing built executable

### Git Workflow

**Current State**: Not using Git yet (no .git directory).

**Recommended Workflow** (when Git is initialized):
- **Branching**: Feature branches from main
- **Commits**: Descriptive messages following conventional commits (e.g., `feat:`, `fix:`, `refactor:`)
- **Build artifacts**: Add `bin/`, `build/`, `frontend/dist/`, `frontend/node_modules/` to `.gitignore`
- **Symlinks**: Document symlinks in README (GameFiles, SDK, Mods are external)

## Domain Context

### Unreal Engine Modding Concepts

**IoStore (Zen Format)**:
- Modern UE asset packaging system (.utoc, .ucas, .pak files)
- Used in UE 5.x games like Grounded 2
- Optimized for streaming and compression

**Legacy Format**:
- Traditional UE assets (.uasset, .uexp files)
- Editable with tools like UAssetGUI, FModel
- Human-readable (with proper tools) and easier to mod

**Modding Workflow**:
1. **Extraction**: Use Retoc to unpack game .pak files to legacy format
2. **Inspection**: Browse/edit .uasset files with UAssetGUI or export to JSON
3. **Modification**: Edit values, properties, or structure
4. **Repacking**: Use Retoc to pack modified assets back to Zen format
5. **Priority**: Mod paks need `_P` suffix to override game files (higher load priority)

**Grounded 2 Specifics**:
- Uses UE 5.4
- Game paks location: `Steam/common/Grounded2/Augusta/Binaries/WinGRTS/Augusta/Content/Paks/`
- Mod paks location: `Steam/common/Grounded2/Augusta/Binaries/WinGRTS/ue4ss/Mods/`
- UE4SS (Unreal Engine Scripting System) used for Lua mods and debugging

### User Personas

**Mod Creator**: Builds new mods or modifies existing game assets
- Needs: Quick iteration, reliable packing, automatic priority handling
- Pain points: Command-line complexity, forgetting paths, manual file naming

**Mod Inspector**: Explores game files to understand structure
- Needs: Easy unpacking, JSON export for readability
- Pain points: Complex extraction commands, managing multiple paths

## Important Constraints

### Technical Constraints
- **Windows-only**: Uses Windows-specific syscalls for folder dialogs (`shell32.dll`)
- **Retoc dependency**: Must be in `retoc/` directory relative to executable (for DLL discovery)
- **UE version compatibility**: Retoc requires correct `--version` flag (UE5_0 through UE5_4 supported)
- **Single-instance**: No multi-window support (Wails v3 limitation in current config)
- **32-bit limit**: Large .pak files (>2GB) may cause issues with file operations

### User Experience Constraints
- **Compact UI**: Designed for 1200x800 windows (not maximized)
- **Always-visible console**: Users expect to see operation output immediately
- **No progress bars**: Current implementation shows console output instead
- **Synchronous operations**: UI blocks during long operations (no background tasks yet)

### Development Constraints
- **Wails v3 alpha**: Using pre-release framework; expect breaking changes
- **UAssetAPI placeholder**: Full JSON export/import not yet implemented (requires C# library integration)
- **No automated deployment**: Manual build and distribution

### Business Constraints
- **Educational/personal use**: Not a commercial product
- **Respect game ToS**: Modding for single-player/co-op only (no competitive advantage)
- **No piracy**: Tools are for legitimate game owners only

## External Dependencies

### Required at Runtime
- **retoc.exe** - IoStore packing/unpacking CLI
  - Location: `<exe_dir>/retoc/retoc.exe`
  - Dependency: `oo2core_9_win64.dll` (Oodle compression library)
  - Source: https://github.com/trumank/retoc

- **UAssetBridge.exe** - UAsset/JSON conversion tool
  - Location: `<exe_dir>/build/UAssetBridge.exe` (configurable)
  - Self-contained .NET 9 executable
  - Future: Will integrate UAssetAPI (https://github.com/atenfyr/UAssetAPI)

### Required at Build Time
- **Go 1.24+** - Backend compilation
- **Wails v3 CLI** - Application bundling
- **.NET 9 SDK** - UAssetBridge compilation
- **Node.js/npm** - Frontend build (Vite)

### Optional External Tools (Referenced)
These tools are mentioned in documentation but not bundled:
- **UAssetGUI** - Visual .uasset editor
- **FModel** - Asset explorer and exporter
- **UE4SS** - Lua modding framework for Unreal Engine
- **Dumper7** - SDK generator for reverse engineering

### External Services
- **None** - Application is fully offline (no telemetry, analytics, or cloud dependencies)

### File System Dependencies
The toolkit uses **symbolic links** to reference external directories:
- `GameFiles` → Extracted game assets (Grounded 2 extracted via FModel)
- `SDK` → Generated C++ SDK for Grounded 2
- `Mods` → UE4SS mods installation directory

These symlinks allow the toolkit to reference large external datasets without duplication. They should be documented but not versioned.

## Development Environment Setup

### First-Time Setup
```bash
# 1. Install Go 1.24+
# 2. Install .NET 9 SDK
# 3. Install Node.js 18+
# 4. Install Wails v3 CLI
go install github.com/wailsapp/wails/cmd/wails3@latest

# 5. Install frontend dependencies
cd ARI-S/frontend
npm install

# 6. Install Go dependencies
cd ..
go mod tidy
```

### Running in Development
```bash
cd ARI-S
wails3 dev
# OR
task dev
```

### Building for Production
```bash
# Full build (recommended)
cd ARI-S
build.bat

# Or step-by-step
cd UAssetBridge/UAssetBridge
dotnet publish -c Release -r win-x64 --self-contained true -o ../../build
cd ../..
wails build
```

## File Naming and Organization Conventions

### Directory Naming
- **kebab-case**: Project directories (`ARI-S`, `UAssetBridge`)
- **lowercase**: Config/build directories (`build`, `bin`, `frontend`, `retoc`)

### File Naming
- **Go files**: `lowercase.go` (e.g., `app.go`, `retoc.go`, `uasset.go`)
- **C# files**: `PascalCase.cs` (e.g., `Program.cs`)
- **JavaScript**: `lowercase.js` (e.g., `main.js`)
- **Config files**: Varies by convention (`config.json`, `Taskfile.yml`, `package.json`)

### Output Naming
- **Executable**: `ARI-S.exe`
- **Mod paks**: Always append `_P` suffix (e.g., `z_ModName_serialization_P.pak`)
- **Extracted folders**: Use game's original directory structure
