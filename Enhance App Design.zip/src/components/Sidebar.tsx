import { motion } from 'motion/react';
import { LayoutDashboard, Package, FileJson, Settings, Box } from 'lucide-react';

interface SidebarProps {
  currentPage: 'dashboard' | 'retoc' | 'uassetapi' | 'settings';
  onNavigate: (page: 'dashboard' | 'retoc' | 'uassetapi' | 'settings') => void;
}

export function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  const navItems = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'retoc' as const, label: 'Retoc', subtitle: 'Zen ⇄ Legacy', icon: Package },
    { id: 'uassetapi' as const, label: 'UAssetAPI', subtitle: 'UAsset ⇄ JSON', icon: FileJson },
    { id: 'settings' as const, label: 'Settings', icon: Settings },
  ];

  return (
    <div className="w-64 bg-gradient-to-b from-[#1a1a1a] to-[#0f0f0f] border-r border-white/5 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-white/5">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-700 rounded-lg flex items-center justify-center">
            <Box className="w-5 h-5" />
          </div>
          <h1 className="tracking-tight">ARIS</h1>
        </div>
        <p className="text-xs text-white/40 leading-relaxed">
          Asset Reconfiguration and Integration System
        </p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <motion.button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className="w-full relative group"
                whileHover={{ x: 4 }}
                whileTap={{ scale: 0.98 }}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-red-600/5 rounded-lg border border-red-500/20"
                    transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                  />
                )}
                
                <div className={`relative flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'text-white' 
                    : 'text-white/60 hover:text-white/90 hover:bg-white/5'
                }`}>
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <div className="flex-1 text-left">
                    <div className="text-sm">{item.label}</div>
                    {item.subtitle && (
                      <div className="text-xs text-white/40">{item.subtitle}</div>
                    )}
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-white/5">
        <div className="px-4 py-3 bg-white/5 rounded-lg">
          <div className="text-xs text-white/40 mb-1">Developed by</div>
          <div className="text-xs text-white/70">Omnient Technologies</div>
        </div>
      </div>
    </div>
  );
}
