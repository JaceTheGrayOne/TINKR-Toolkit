# Build System Specification (Delta)

## ADDED Requirements

### Requirement: Resource File Copying
The build system SHALL correctly copy external tool dependencies from the Resources directory to the build output directory.

#### Scenario: Retoc files copied to build directory
- **WHEN** build.bat is executed
- **THEN** retoc.exe is copied from Resources/retoc/ to ARI-S/build/
- **AND** oo2core_9_win64.dll is copied from Resources/retoc/ to ARI-S/build/
- **AND** both files exist at build/retoc.exe and build/oo2core_9_win64.dll after build completes

#### Scenario: Correct path navigation between project directories
- **WHEN** build script navigates from ARI-S/UAssetBridge/UAssetBridge to Resources/retoc
- **THEN** the script uses relative path `..\..\..\Resources\retoc` (up three levels)
- **AND** the script successfully changes to the Resources/retoc directory
- **AND** no "directory not found" errors occur

#### Scenario: Build completes successfully with all dependencies
- **WHEN** build.bat runs to completion
- **THEN** UAssetBridge.exe exists in build/ directory
- **AND** retoc.exe exists in build/ directory
- **AND** oo2core_9_win64.dll exists in build/ directory
- **AND** final Wails build succeeds
- **AND** bin/ARI-S.exe is created

### Requirement: Build Script Path Correctness
The build system SHALL use correct relative paths when navigating between project subdirectories.

#### Scenario: Navigate from nested project directory to sibling Resources
- **WHEN** current working directory is ARI-S/UAssetBridge/UAssetBridge/
- **THEN** navigating to Resources/retoc/ requires going up three directory levels
- **AND** the command `cd ..\..\..\Resources\retoc` is used
- **AND** the script does not attempt `cd ..\..\Resources\retoc` (which would fail)

#### Scenario: Return to ARI-S root after resource copying
- **WHEN** resource files have been copied from Resources/retoc/
- **THEN** the script navigates back to ARI-S root directory
- **AND** subsequent wails build command executes from correct location
