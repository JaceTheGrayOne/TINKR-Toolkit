import { motion } from 'motion/react';
import { Settings as SettingsIcon, Monitor, Palette, Bell, Shield, HardDrive } from 'lucide-react';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';

export function Settings() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#0f0f0f] to-[#1a1a1a]">
      {/* Header */}
      <div className="border-b border-white/5 bg-black/20 backdrop-blur-xl sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500/20 to-purple-600/20 rounded-lg flex items-center justify-center border border-purple-500/20">
              <SettingsIcon className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h1 className="text-xl mb-0.5">Settings</h1>
              <p className="text-xs text-white/40">Configure ARIS application preferences</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-8 py-8 space-y-6">
        {/* Application Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <div className="flex items-center gap-3 mb-6">
              <Monitor className="w-5 h-5 text-blue-400" />
              <h2 className="text-lg">Application</h2>
            </div>

            <div className="space-y-6">
              <SettingRow
                label="Default UE Version"
                description="Set the default Unreal Engine version for operations"
              >
                <Select defaultValue="UE5.4">
                  <SelectTrigger className="w-48 bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="UE5.4">UE 5.4</SelectItem>
                    <SelectItem value="UE5.3">UE 5.3</SelectItem>
                    <SelectItem value="UE5.2">UE 5.2</SelectItem>
                  </SelectContent>
                </Select>
              </SettingRow>

              <Separator className="bg-white/5" />

              <SettingRow
                label="Auto-save Console Logs"
                description="Automatically save console output to log files"
              >
                <Switch defaultChecked />
              </SettingRow>

              <Separator className="bg-white/5" />

              <SettingRow
                label="Verbose Logging"
                description="Enable detailed logging for debugging purposes"
              >
                <Switch />
              </SettingRow>
            </div>
          </Card>
        </motion.div>

        {/* Interface Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <div className="flex items-center gap-3 mb-6">
              <Palette className="w-5 h-5 text-purple-400" />
              <h2 className="text-lg">Interface</h2>
            </div>

            <div className="space-y-6">
              <SettingRow
                label="Theme"
                description="Application color theme"
              >
                <Select defaultValue="dark">
                  <SelectTrigger className="w-48 bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="auto">Auto</SelectItem>
                  </SelectContent>
                </Select>
              </SettingRow>

              <Separator className="bg-white/5" />

              <SettingRow
                label="Animations"
                description="Enable interface animations and transitions"
              >
                <Switch defaultChecked />
              </SettingRow>
            </div>
          </Card>
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="w-5 h-5 text-yellow-400" />
              <h2 className="text-lg">Notifications</h2>
            </div>

            <div className="space-y-6">
              <SettingRow
                label="Operation Complete"
                description="Notify when operations finish successfully"
              >
                <Switch defaultChecked />
              </SettingRow>

              <Separator className="bg-white/5" />

              <SettingRow
                label="Error Alerts"
                description="Display alerts when errors occur"
              >
                <Switch defaultChecked />
              </SettingRow>
            </div>
          </Card>
        </motion.div>

        {/* Advanced */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="w-5 h-5 text-red-400" />
              <h2 className="text-lg">Advanced</h2>
            </div>

            <div className="space-y-6">
              <SettingRow
                label="Parallel Processing"
                description="Enable multi-threaded file processing"
              >
                <Switch defaultChecked />
              </SettingRow>

              <Separator className="bg-white/5" />

              <SettingRow
                label="Compression Level"
                description="Set output file compression level"
              >
                <Select defaultValue="balanced">
                  <SelectTrigger className="w-48 bg-white/5 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="fast">Fast</SelectItem>
                    <SelectItem value="balanced">Balanced</SelectItem>
                    <SelectItem value="maximum">Maximum</SelectItem>
                  </SelectContent>
                </Select>
              </SettingRow>
            </div>
          </Card>
        </motion.div>

        {/* System Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <div className="flex items-center gap-3 mb-6">
              <HardDrive className="w-5 h-5 text-cyan-400" />
              <h2 className="text-lg">System Information</h2>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <InfoItem label="Version" value="1.0.0" />
              <InfoItem label="Build" value="2024.10.21" />
              <InfoItem label="retoc" value="Integrated" />
              <InfoItem label="UAssetAPI" value="Integrated" />
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}

function SettingRow({ 
  label, 
  description, 
  children 
}: { 
  label: string; 
  description: string; 
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex-1">
        <Label className="text-white/90 text-sm">{label}</Label>
        <p className="text-xs text-white/40 mt-1">{description}</p>
      </div>
      <div>{children}</div>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-3 bg-white/5 rounded-lg border border-white/10">
      <p className="text-xs text-white/40 mb-1">{label}</p>
      <p className="text-sm text-white/90">{value}</p>
    </div>
  );
}
