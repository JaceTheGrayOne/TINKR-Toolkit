# UAsset Service Specification (Delta)

## ADDED Requirements

### Requirement: File Counting UI Integration
The UAsset service frontend SHALL display accurate file counts by calling backend counting methods.

#### Scenario: Export folder displays uasset and uexp file counts
- **WHEN** user enters or browses to a folder in the export-folder input
- **THEN** updateExportFileCount() calls UAssetService.CountUAssetFiles(folderPath)
- **AND** the returned counts are displayed in the file-count-value element
- **AND** the display shows format "X .uasset, Y .uexp"
- **AND** no placeholder "Counting files..." message remains indefinitely

#### Scenario: Import folder displays json file count
- **WHEN** user enters or browses to a folder in the import-folder input
- **THEN** updateImportFileCount() calls UAssetService.CountJSONFiles(folderPath)
- **AND** the returned count is displayed in the file-count-value element
- **AND** the display shows format "X .json"
- **AND** no placeholder "Counting files..." message remains indefinitely

#### Scenario: File counting handles errors gracefully
- **WHEN** file counting operation fails (folder doesn't exist, permission denied)
- **THEN** an error is caught and handled
- **AND** user sees a meaningful error message
- **AND** the application does not crash
- **AND** file count display shows "Error counting files" or similar

#### Scenario: File counting updates on folder change
- **WHEN** user changes the folder path in the input field
- **THEN** file counting is triggered automatically
- **AND** counts update to reflect the new folder's contents
- **AND** previous counts are cleared before new counts display

### Requirement: Dead Code Removal
The UAsset service frontend SHALL not contain unused functions or commented-out features.

#### Scenario: Unused utility functions are removed
- **WHEN** browseFile() function exists but is never called
- **THEN** the function is removed from main.js
- **AND** no commented TODO references to it remain

#### Scenario: Removed UI features have code cleaned up
- **WHEN** openFolder() function exists for removed "Open" buttons
- **THEN** the function is removed from main.js
- **AND** no event listeners reference it
- **AND** no dead code remains
