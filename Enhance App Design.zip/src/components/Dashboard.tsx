import { motion } from 'motion/react';
import { Package, FileJson, ArrowRight, Boxes, Download, Upload, FileCode } from 'lucide-react';
import { Card } from './ui/card';

interface DashboardProps {
  onNavigate: (page: 'retoc' | 'uassetapi') => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#0f0f0f] to-[#1a1a1a]">
      {/* Header */}
      <div className="border-b border-white/5 bg-black/20 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-8 py-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="mb-2">
              ARIS - Asset Reconfiguration and Integration System
            </h1>
            <p className="text-white/50 text-sm max-w-3xl">
              Developed by researchers at Omnient Technologies' Practical Applications Division.
              <br />
              The Asset Reconfiguration and Integration System (ARIS) facilitates direct manipulation of simulation architecture.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-8 py-12">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Zen ⇄ Legacy Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card 
              className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 hover:border-red-500/30 transition-all duration-300 overflow-hidden group cursor-pointer h-full"
              onClick={() => onNavigate('retoc')}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-red-500/0 via-red-500/0 to-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative p-8">
                {/* Icon Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-orange-500/20 to-red-600/20 rounded-xl flex items-center justify-center border border-orange-500/20 group-hover:scale-110 transition-transform duration-300">
                      <Package className="w-7 h-7 text-orange-400" />
                    </div>
                    <div>
                      <h2 className="text-xl mb-1">Zen ⇄ Legacy</h2>
                      <p className="text-xs text-white/40">IoStore Format Conversion</p>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-white/20 group-hover:text-red-400 group-hover:translate-x-1 transition-all duration-300" />
                </div>

                {/* Description */}
                <p className="text-sm text-white/50 mb-8 leading-relaxed">
                  Loading an <span className="text-red-400">IoStore</span> chunked by <span className="text-red-400">Serialization Protocol</span>
                </p>

                {/* Operations */}
                <div className="space-y-4">
                  <OperationItem
                    icon={<Boxes className="w-4 h-4" />}
                    badge="PACK"
                    title="Pack modified assets into finished mods"
                    subtitle="Legacy → Zen"
                    color="orange"
                  />
                  <OperationItem
                    icon={<Download className="w-4 h-4" />}
                    badge="UNPACK"
                    title="Unpack game files into modifiable assets"
                    subtitle="Zen → Legacy"
                    color="orange"
                  />
                </div>
              </div>
            </Card>
          </motion.div>

          {/* UAsset ⇄ JSON Card */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card 
              className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 hover:border-blue-500/30 transition-all duration-300 overflow-hidden group cursor-pointer h-full"
              onClick={() => onNavigate('uassetapi')}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/0 via-blue-500/0 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative p-8">
                {/* Icon Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-xl flex items-center justify-center border border-cyan-500/20 group-hover:scale-110 transition-transform duration-300">
                      <FileJson className="w-7 h-7 text-cyan-400" />
                    </div>
                    <div>
                      <h2 className="text-xl mb-1">UAsset ⇄ JSON</h2>
                      <p className="text-xs text-white/40">Asset Data Serialization</p>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-white/20 group-hover:text-blue-400 group-hover:translate-x-1 transition-all duration-300" />
                </div>

                {/* Description */}
                <p className="text-sm text-white/50 mb-8 leading-relaxed">
                  Reading an <span className="text-cyan-400">UAsset/UExp</span> based on <span className="text-cyan-400">Serialization Protocol</span>
                </p>

                {/* Operations */}
                <div className="space-y-4">
                  <OperationItem
                    icon={<FileCode className="w-4 h-4" />}
                    badge="EXPORT"
                    title="Convert extracted asset files to JSON"
                    subtitle="UAsset → JSON"
                    color="cyan"
                  />
                  <OperationItem
                    icon={<Upload className="w-4 h-4" />}
                    badge="IMPORT"
                    title="Convert JSON files to UAsset"
                    subtitle="JSON → UAsset"
                    color="cyan"
                  />
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Quick Stats or Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-8 grid grid-cols-3 gap-6"
        >
          <StatCard label="System Status" value="Operational" color="green" />
          <StatCard label="Active Protocol" value="UE 5.x" color="blue" />
          <StatCard label="Pipeline Ready" value="Yes" color="purple" />
        </motion.div>
      </div>
    </div>
  );
}

function OperationItem({ 
  icon, 
  badge, 
  title, 
  subtitle, 
  color 
}: { 
  icon: React.ReactNode; 
  badge: string; 
  title: string; 
  subtitle: string; 
  color: 'orange' | 'cyan';
}) {
  const colorClasses = {
    orange: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    cyan: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  };

  return (
    <div className="flex items-start gap-3 p-4 rounded-lg bg-white/5 border border-white/5 hover:border-white/10 transition-all duration-200 group/item">
      <div className={`mt-0.5 p-2 rounded-lg ${colorClasses[color]} border`}>
        {icon}
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className={`text-xs px-2 py-0.5 rounded ${colorClasses[color]} border`}>
            {badge}
          </span>
          <span className="text-xs text-white/30">{subtitle}</span>
        </div>
        <p className="text-sm text-white/70 group-hover/item:text-white/90 transition-colors">
          {title}
        </p>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string; color: 'green' | 'blue' | 'purple' }) {
  const colorClasses = {
    green: 'from-emerald-500/20 to-green-600/5 border-emerald-500/20',
    blue: 'from-blue-500/20 to-blue-600/5 border-blue-500/20',
    purple: 'from-purple-500/20 to-purple-600/5 border-purple-500/20',
  };

  const dotColors = {
    green: 'bg-emerald-400',
    blue: 'bg-blue-400',
    purple: 'bg-purple-400',
  };

  return (
    <div className={`bg-gradient-to-br ${colorClasses[color]} border rounded-lg p-4`}>
      <div className="flex items-center gap-2 mb-2">
        <div className={`w-2 h-2 ${dotColors[color]} rounded-full animate-pulse`} />
        <p className="text-xs text-white/40">{label}</p>
      </div>
      <p className="text-white/90">{value}</p>
    </div>
  );
}
