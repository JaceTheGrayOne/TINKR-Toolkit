import { Terminal, CheckCircle2, AlertCircle, Info } from 'lucide-react';
import { Card } from './ui/card';
import { ScrollArea } from './ui/scroll-area';

interface ConsoleLogProps {
  logs: string[];
}

export function ConsoleLog({ logs }: ConsoleLogProps) {
  const getLogIcon = (log: string) => {
    if (log.toLowerCase().includes('success') || log.toLowerCase().includes('completed')) {
      return <CheckCircle2 className="w-3 h-3 text-green-400 flex-shrink-0" />;
    }
    if (log.toLowerCase().includes('error') || log.toLowerCase().includes('failed')) {
      return <AlertCircle className="w-3 h-3 text-red-400 flex-shrink-0" />;
    }
    return <Info className="w-3 h-3 text-blue-400 flex-shrink-0" />;
  };

  const getLogColor = (log: string) => {
    if (log.toLowerCase().includes('success') || log.toLowerCase().includes('completed')) {
      return 'text-green-400';
    }
    if (log.toLowerCase().includes('error') || log.toLowerCase().includes('failed')) {
      return 'text-red-400';
    }
    if (log.toLowerCase().includes('idle')) {
      return 'text-white/40';
    }
    return 'text-white/70';
  };

  return (
    <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 overflow-hidden">
      <div className="flex items-center gap-2 px-6 py-3 border-b border-white/10 bg-black/20">
        <Terminal className="w-4 h-4 text-green-400" />
        <h3 className="text-sm">Console Log</h3>
        <div className="ml-auto flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-xs text-white/40">Active</span>
        </div>
      </div>
      
      <ScrollArea className="h-48">
        <div className="p-4 space-y-2 font-mono text-xs">
          {logs.map((log, index) => (
            <div key={index} className="flex items-start gap-2 group">
              <span className="text-white/20 select-none min-w-[2rem] text-right">{index + 1}</span>
              {getLogIcon(log)}
              <span className={`${getLogColor(log)} group-hover:text-white/90 transition-colors`}>
                {log}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </Card>
  );
}
