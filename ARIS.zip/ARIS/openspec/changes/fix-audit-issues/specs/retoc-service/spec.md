# Retoc Service Specification (Delta)

## ADDED Requirements

### Requirement: Output File Renaming Logic
The Retoc service SHALL correctly detect when output file renaming is required and execute the renaming operation.

#### Scenario: File renaming triggered when options provided
- **WHEN** RunRetoc is called with command "to-zen"
- **AND** operation.Options contains mod name and serialization values
- **THEN** the file renaming condition evaluates to true
- **AND** renameOutputFiles function is called
- **AND** output files are renamed to include _P priority suffix

#### Scenario: Empty options array does not trigger renaming
- **WHEN** RunRetoc is called with command "to-zen"
- **AND** operation.Options is an empty slice (length 0)
- **THEN** the condition `len(operation.Options) > 0` evaluates to false
- **AND** renameOutputFiles is not called
- **AND** files retain their original retoc-generated names

#### Scenario: Nil options does not trigger renaming
- **WHEN** RunRetoc is called with command "to-zen"
- **AND** operation.Options is nil
- **THEN** the condition `len(operation.Options) > 0` evaluates to false
- **AND** renameOutputFiles is not called

### Requirement: Code Maintainability
The Retoc service SHALL not contain unused or dead code unless explicitly documented for future use.

#### Scenario: Unused methods are removed or documented
- **WHEN** DetectUEVersion method exists but is never called
- **THEN** either the method is removed from the codebase
- **OR** a comment explains its retention for future functionality
- **AND** the decision is documented in code comments or design docs

#### Scenario: Helper methods are wired to frontend or removed
- **WHEN** GetAvailableUEVersions method exists but is never called
- **THEN** either the method is wired up to frontend UI
- **OR** the method is removed from the codebase
- **AND** no dead code remains without justification
