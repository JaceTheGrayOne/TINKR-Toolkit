import { useState } from 'react';
import { motion } from 'motion/react';
import { FileJson, FolderOpen, Upload, Download, CheckCircle2 } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { ConsoleLog } from './ConsoleLog';

export function UAssetAPI() {
  const [logs, setLogs] = useState<string[]>(['Idle...']);

  const handleExport = () => {
    setLogs([...logs, 'Exporting to JSON...', 'Files found: 3 .uasset, 0 .uexp', 'Export completed successfully.']);
  };

  const handleImport = () => {
    setLogs([...logs, 'Importing from JSON...', 'Files found: 5 .json', 'Import completed successfully.']);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#0f0f0f] to-[#1a1a1a]">
      {/* Header */}
      <div className="border-b border-white/5 bg-black/20 backdrop-blur-xl sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-lg flex items-center justify-center border border-cyan-500/20">
              <FileJson className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-xl mb-0.5">Asset Reconfiguration</h1>
              <p className="text-xs text-white/40">
                • Reconfigure simulation artifact format.
                <br />• Recalibrate simulation artifact properties.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-8 py-8 space-y-6">
        {/* Export to JSON Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-lg mb-1 flex items-center gap-2">
                  Export to JSON (UAsset → JSON)
                </h2>
                <p className="text-xs text-white/40">
                  Convert extracted asset files to JSON format for editing.
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-red-500/10 to-red-600/5 rounded-lg flex items-center justify-center border border-red-500/20">
                <Upload className="w-6 h-6 text-red-400" />
              </div>
            </div>

            <div className="space-y-5">
              <FileInputGroup
                label="Select folder containing .uasset/.uexp files:"
                placeholder="C:\_UAssets"
                badge="3 .uasset, 0 .uexp"
              />

              <div className="flex justify-end">
                <Button 
                  onClick={handleExport}
                  className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white border-0 shadow-lg shadow-red-500/20"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Export to JSON
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Import from JSON Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-lg mb-1 flex items-center gap-2">
                  Import from JSON
                </h2>
                <p className="text-xs text-white/40">
                  Convert JSON files back to .uasset/.uexp format.
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-green-500/10 to-green-600/5 rounded-lg flex items-center justify-center border border-green-500/20">
                <Download className="w-6 h-6 text-green-400" />
              </div>
            </div>

            <div className="space-y-5">
              <FileInputGroup
                label="Select folder containing .json files:"
                placeholder="C:\_UAssets"
                badge="5 .json"
              />

              <div className="flex justify-end">
                <Button 
                  onClick={handleImport}
                  className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white border-0 shadow-lg shadow-green-500/20"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Import from JSON
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Info Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="grid md:grid-cols-3 gap-4"
        >
          <InfoCard
            icon={<FileJson className="w-5 h-5 text-cyan-400" />}
            label="JSON Format"
            value="Human-readable"
            color="cyan"
          />
          <InfoCard
            icon={<CheckCircle2 className="w-5 h-5 text-green-400" />}
            label="Conversion"
            value="Lossless"
            color="green"
          />
          <InfoCard
            icon={<Upload className="w-5 h-5 text-purple-400" />}
            label="Batch Processing"
            value="Supported"
            color="purple"
          />
        </motion.div>

        {/* Console Log */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <ConsoleLog logs={logs} />
        </motion.div>
      </div>
    </div>
  );
}

function FileInputGroup({ 
  label, 
  placeholder,
  badge 
}: { 
  label: string; 
  placeholder: string;
  badge?: string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <Label className="text-white/70 text-sm">{label}</Label>
        {badge && (
          <span className="text-xs px-2 py-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded">
            {badge}
          </span>
        )}
      </div>
      <div className="relative group">
        <Input 
          className="bg-white/5 border-white/10 text-white placeholder:text-white/20 pr-24 hover:bg-white/10 focus:bg-white/10 transition-colors"
          placeholder={placeholder}
        />
        <Button 
          size="sm"
          className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white border-white/10 h-7 text-xs"
        >
          <FolderOpen className="w-3 h-3 mr-1.5" />
          Browse
        </Button>
      </div>
    </div>
  );
}

function InfoCard({ 
  icon, 
  label, 
  value, 
  color 
}: { 
  icon: React.ReactNode; 
  label: string; 
  value: string; 
  color: 'cyan' | 'green' | 'purple';
}) {
  const colorClasses = {
    cyan: 'from-cyan-500/20 to-cyan-600/5 border-cyan-500/20',
    green: 'from-green-500/20 to-green-600/5 border-green-500/20',
    purple: 'from-purple-500/20 to-purple-600/5 border-purple-500/20',
  };

  return (
    <div className={`bg-gradient-to-br ${colorClasses[color]} border rounded-lg p-4`}>
      <div className="flex items-center gap-3 mb-2">
        {icon}
        <p className="text-xs text-white/50">{label}</p>
      </div>
      <p className="text-white/90">{value}</p>
    </div>
  );
}
