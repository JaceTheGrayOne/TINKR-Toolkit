# Change Proposal: Fix Audit Issues

## Why

A comprehensive audit revealed multiple critical issues preventing successful builds and runtime operation of ARI-S. These issues range from incorrect build script paths that prevent required dependencies from being copied, to configuration mismatches that cause services to fail at runtime. Additionally, the project contains placeholder naming and dead code from the initial Cursor scaffolding phase that needs cleanup.

**Key Problems:**
- Build script cannot copy retoc.exe and oo2core_9_win64.dll due to incorrect relative paths
- UAssetBridge default configuration path is wrong, causing service to always fail
- Retoc file renaming logic has a condition that never evaluates to true
- Module name "changeme" is a placeholder that should match actual project identity
- Frontend file counting displays "Counting files..." but never calls backend methods
- Stale comments reference old project name "TINK.R Toolkit" instead of "ARI-S"

## What Changes

### Critical Fixes (Build/Runtime Blockers)
- **Build System**: Fix relative path navigation in build.bat to correctly copy retoc files from Resources directory
- **Config Management**: Update UAssetBridge default path to match actual build output location
- **Retoc Service**: Fix file renaming logic condition to properly detect when renaming should occur
- **Project Identity**: Replace "changeme" module name with "aris" throughout codebase
- **UAsset Service**: Wire up frontend file counting to backend CountUAssetFiles and CountJSONFiles methods

### Quality Improvements (Non-blocking)
- **Code Cleanup**: Remove dead code (unused DetectUEVersion, GetAvailableUEVersions, browseFile, openFolder)
- **Branding**: Update all references from "TINK.R Toolkit" to "ARI-S" or "ARI.S" for consistency
- **Documentation**: Align CLAUDE.md configuration paths with actual implementation

## Impact

**Affected specs:**
- `build-system` (new capability)
- `config-management` (new capability)
- `retoc-service` (new capability)
- `uasset-service` (new capability)
- `project-identity` (new capability)

**Affected code:**
- `ARI-S/build.bat` - Fix path navigation and file copying
- `ARI-S/config.go` - Update UAssetBridge default path
- `ARI-S/retoc.go` - Fix renaming condition, remove unused methods
- `ARI-S/uasset.go` - No changes (file counting methods already exist)
- `ARI-S/main.js` - Wire up file counting, remove unused functions
- `ARI-S/go.mod` - Update module name from "changeme" to "aris"
- `ARI-S/frontend/bindings/` - Regenerate after module name change
- `CLAUDE.md` - Update comments and configuration paths

**User impact:**
- Application will build successfully and include all required dependencies
- Retoc service will function correctly with proper file paths
- UAsset service will locate UAssetBridge.exe and execute operations
- File counting UI will display accurate results
- Professional module naming improves code quality

**Developer impact:**
- Build process becomes reliable and repeatable
- Module imports use proper project name
- Reduced confusion from placeholder/stale references
- Cleaner codebase with dead code removed

**Breaking changes:** None - these are all internal fixes
