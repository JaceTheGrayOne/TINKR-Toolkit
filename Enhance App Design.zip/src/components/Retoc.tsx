import { useState } from 'react';
import { motion } from 'motion/react';
import { FolderOpen, Play, Package, Download, CheckCircle2, AlertCircle } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { ConsoleLog } from './ConsoleLog';

export function Retoc() {
  const [ueVersion, setUeVersion] = useState('UE5.4');
  const [logs, setLogs] = useState<string[]>(['Idle...']);

  const handleExecute = (operation: string) => {
    setLogs([...logs, `Executing ${operation}...`, 'Processing files...', 'Operation completed successfully.']);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#0f0f0f] to-[#1a1a1a]">
      {/* Header */}
      <div className="border-b border-white/5 bg-black/20 backdrop-blur-xl sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500/20 to-red-600/20 rounded-lg flex items-center justify-center border border-orange-500/20">
              <Package className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <h1 className="text-xl mb-0.5">Extract / Prepare</h1>
              <p className="text-xs text-white/40">Zen ⇄ Legacy Format Conversion</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-8 py-8 space-y-6">
        {/* Configuration Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <h2 className="mb-6 flex items-center gap-2">
              <span className="text-lg">Configuration</span>
            </h2>
            
            <div className="space-y-4">
              <div>
                <Label className="text-white/70 mb-2 block">UE Version:</Label>
                <Select value={ueVersion} onValueChange={setUeVersion}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white hover:bg-white/10 transition-colors">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    <SelectItem value="UE5.4">UE5.4</SelectItem>
                    <SelectItem value="UE5.3">UE5.3</SelectItem>
                    <SelectItem value="UE5.2">UE5.2</SelectItem>
                    <SelectItem value="UE5.1">UE5.1</SelectItem>
                    <SelectItem value="UE5.0">UE5.0</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Prepare Override Files Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <h2 className="mb-2 flex items-center gap-2">
              <span className="text-lg">Prepare Override Files</span>
            </h2>
            <p className="text-xs text-white/40 mb-6">
              Loader (uasset | utoc) → Zen (uloc | ucas | pak)
            </p>

            <div className="space-y-5">
              <FileInputGroup
                label="Reconfigured Asset Input:"
                placeholder="C:\_Modded"
                helperText="Path to modified assets"
              />

              <FileInputGroup
                label="Override Asset Output:"
                placeholder="C:\Users\_Desktop\ReCon_Builds"
                helperText="Destination for packed files"
              />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-white/70 mb-2 block text-sm">Override Asset Base Name:</Label>
                  <Input 
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/20 hover:bg-white/10 focus:bg-white/10 transition-colors"
                    placeholder="Enter base name..."
                  />
                </div>
                <div>
                  <Label className="text-white/70 mb-2 block text-sm">Override Asset Sanitization (Ex. _XXXX):</Label>
                  <Input 
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/20 hover:bg-white/10 focus:bg-white/10 transition-colors"
                    placeholder="Enter sanitization..."
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-white/5 rounded-lg border border-white/10">
                <Checkbox id="copy-override" className="border-white/30" />
                <label htmlFor="copy-override" className="text-sm text-white/70 cursor-pointer">
                  Copy override assets to simulation artifact directory (/paks)?
                </label>
              </div>

              <div className="flex justify-end">
                <Button 
                  onClick={() => handleExecute('Prepare Override')}
                  className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white border-0 shadow-lg shadow-red-500/20"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Execute
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Extract Simulation Artifacts Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <Card className="bg-gradient-to-br from-white/5 to-white/0 border-white/10 p-6">
            <h2 className="mb-2 flex items-center gap-2">
              <span className="text-lg">Extract Simulation Artifacts</span>
            </h2>
            <p className="text-xs text-white/40 mb-6">
              Zen (ucas | utoc | pak) → Legacy (uasset | uexp)
            </p>

            <div className="space-y-5">
              <FileInputGroup
                label="Simulation Artifact Directory (/paks):"
                placeholder="C:\_Paks"
                helperText="Source directory containing pak files"
                badge="2 paths detected"
              />

              <FileInputGroup
                label="Simulation Artifact Storage:"
                placeholder="C:\Users\_Desktop\ReCon_E_xtracted"
                helperText="Destination for extracted assets"
              />

              <div className="flex justify-end">
                <Button 
                  onClick={() => handleExecute('Extract Simulation Artifacts')}
                  className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white border-0 shadow-lg shadow-green-500/20"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Execute
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Console Log */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <ConsoleLog logs={logs} />
        </motion.div>
      </div>
    </div>
  );
}

function FileInputGroup({ 
  label, 
  placeholder, 
  helperText,
  badge 
}: { 
  label: string; 
  placeholder: string; 
  helperText: string;
  badge?: string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <Label className="text-white/70 text-sm">{label}</Label>
        {badge && (
          <span className="text-xs px-2 py-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded">
            {badge}
          </span>
        )}
      </div>
      <div className="relative group">
        <Input 
          className="bg-white/5 border-white/10 text-white placeholder:text-white/20 pr-24 hover:bg-white/10 focus:bg-white/10 transition-colors"
          placeholder={placeholder}
        />
        <Button 
          size="sm"
          className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 text-white border-white/10 h-7 text-xs"
        >
          <FolderOpen className="w-3 h-3 mr-1.5" />
          Browse
        </Button>
      </div>
      {helperText && <p className="text-xs text-white/30 mt-1.5">{helperText}</p>}
    </div>
  );
}
