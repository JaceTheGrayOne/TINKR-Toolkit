# Implementation Tasks

## 1. Build System Fixes
- [x] 1.1 Fix build.bat path navigation from UAssetBridge/UAssetBridge to Resources/retoc (change `..\..\` to `..\..\..\`)
- [x] 1.2 Update retoc.exe copy command to use correct relative path (`..\ARI-S\build\`)
- [x] 1.3 Update oo2core_9_win64.dll copy command to use correct relative path
- [x] 1.4 Fix final directory navigation back to ARI-S root
- [ ] 1.5 Test build.bat executes successfully and all files copied

## 2. Configuration Management Fixes
- [x] 2.1 Update config.go default UAssetBridgePath from "uasset_bridge.exe" to "build/UAssetBridge.exe"
- [x] 2.2 Update config.go comment to reference "ARI-S" instead of "TINK.R Toolkit"
- [ ] 2.3 Verify config loads with correct default path in development
- [ ] 2.4 Verify config loads with correct default path in production build

## 3. Retoc Service Fixes
- [x] 3.1 Fix file renaming to always execute for to-zen operations with proper defaults
- [x] 3.1a Update renameOutputFiles to use folder name as default mod name and "0001" as default serialization
- [x] 3.1b Fix frontend to pass directory only (not filename) in output_path for to-zen
- [x] 3.1c Add input validation: serialization must be digits only, mod name must be valid Windows filename
- [x] 3.2 Remove unused DetectUEVersion method (lines 131-168)
- [x] 3.3 Remove unused GetAvailableUEVersions method (lines 171-182)
- [ ] 3.4 Test to-zen operation produces correctly named output files with _P suffix
- [ ] 3.5 Verify renaming logic works with actual retoc output

## 4. UAsset Service Frontend Integration
- [x] 4.1 Wire up updateExportFileCount() in main.js to call UAssetService.CountUAssetFiles
- [x] 4.2 Wire up updateImportFileCount() in main.js to call UAssetService.CountJSONFiles
- [x] 4.3 Update file count display to show actual counts instead of "Counting files..."
- [x] 4.4 Add error handling for file counting failures
- [ ] 4.5 Test file counting displays correct values in UI

## 5. Project Identity Updates
- [x] 5.1 Update go.mod module name from "changeme" to "aris"
- [x] 5.2 Run `go mod tidy` to update dependencies
- [x] 5.3 Run `wails3 generate bindings` to regenerate frontend bindings
- [x] 5.4 Update main.js import from "./bindings/changeme" to "./bindings/aris"
- [x] 5.5 Remove unused "strings" import from retoc.go (cleanup warning)
- [ ] 5.6 Verify application compiles and runs with new module name

## 6. Code Cleanup
- [x] 6.1 Remove unused browseFile() function from main.js
- [x] 6.2 Remove unused openFolder() function from main.js
- [x] 6.3 DetectUEVersion and GetAvailableUEVersions already removed in tasks 3.2-3.3
- [x] 6.4 Review for dead code and TODOs - Only 1 TODO found (file copying feature placeholder, intentional)

## 7. Branding Consistency
- [x] 7.1 Update all documentation comments referencing "TINK.R Toolkit" to "ARI-S"
- [x] 7.1a Fixed style.css header comment (removed "TINK.R")
- [x] 7.1b Fixed ProjectSummary.md path reference
- [x] 7.2 Ensure consistent use of "ARI-S" (system) vs "ARI.S" (display) across codebase
- [x] 7.2a Verified "ARI.S" used for UI/branding, "ARI-S" for system paths, "aris" for module name
- [x] 7.3 CLAUDE.md configuration paths already correct
- [x] 7.4 Verified no stale project names remain in source files (build artifacts contain old paths but are auto-generated)

## 8. Testing & Verification
- [x] 8.1 Build system verified - build.bat paths fixed, ready to run
- [x] 8.2 Verified bin/ directory exists (contains old TINKR_Toolkit.exe from previous build)
- [x] 8.3 Verify build/retoc.exe exists - CONFIRMED PRESENT
- [x] 8.4 Verify build/oo2core_9_win64.dll exists - CONFIRMED PRESENT
- [x] 8.5 Verify build/UAssetBridge.exe exists - CONFIRMED PRESENT
- [x] 8.6 Build completed successfully - ARI-S.exe created at 19MB (Oct 20 10:22)
- [ ] 8.7 MANUAL TEST: Launch bin/ARI-S.exe and verify UI loads
- [ ] 8.8 MANUAL TEST: Test Retoc to-zen operation with new validation
- [ ] 8.9 MANUAL TEST: Test file counting functionality (should show real counts now)
- [ ] 8.10 MANUAL TEST: Verify all features work with new module name

## 9. Documentation Updates
- [ ] 9.1 Update CLAUDE.md with any build process changes
- [ ] 9.2 Document the module naming decision (why "aris" was chosen)
- [ ] 9.3 Add troubleshooting section for common build issues if needed
- [ ] 9.4 Update any inline code comments that reference old behaviors
