# Configuration Management Specification (Delta)

## ADDED Requirements

### Requirement: External Tool Path Configuration
The configuration system SHALL provide correct default paths for external tool executables relative to the application's runtime location.

#### Scenario: UAssetBridge default path matches build output
- **WHEN** configuration is initialized with default values
- **THEN** UAssetBridgePath is set to "build/UAssetBridge.exe"
- **AND** the path correctly points to where build.bat outputs the executable
- **AND** the path is relative to the application executable directory

#### Scenario: UAssetBridge executable can be located at runtime
- **WHEN** UAssetService attempts to execute UAssetBridge
- **THEN** the executable is found at the configured path
- **AND** no "file not found" error occurs
- **AND** the service can successfully invoke UAssetBridge.exe

#### Scenario: Configuration comments reflect actual project name
- **WHEN** configuration source code contains comments about file locations
- **THEN** comments reference "ARI-S" as the project name
- **AND** no references to "TINK.R Toolkit" remain in comments
- **AND** comments accurately describe the current project structure

### Requirement: Configuration Path Documentation
Configuration path documentation SHALL match the actual implementation paths used at runtime.

#### Scenario: Documented config location matches implementation
- **WHEN** CLAUDE.md or project.md documents configuration file location
- **THEN** documentation states config is at "%USERPROFILE%\AppData\Local\ARI-S\config.json"
- **AND** implementation in app.go:54 matches this path
- **AND** no discrepancies exist between docs and code
