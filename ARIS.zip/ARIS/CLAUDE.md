<!-- OPENSPEC:START -->
# OpenSpec Instructions

These instructions are for AI assistants working in this project.

Always open `@/openspec/AGENTS.md` when the request:
- Mentions planning or proposals (words like proposal, spec, change, plan)
- Introduces new capabilities, breaking changes, architecture shifts, or big performance/security work
- Sounds ambiguous and you need the authoritative spec before coding

Use `@/openspec/AGENTS.md` to learn:
- How to create and apply change proposals
- Spec format and conventions
- Project structure and guidelines

Keep this managed block so 'openspec update' can refresh the instructions.

<!-- OPENSPEC:END -->

# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**ARI.S** (Asset Reconfiguration and Integration System) is a Windows desktop application for Unreal Engine modding, specifically designed for Grounded 2. It provides a modern GUI for managing Retoc (IoStore operations) and UAsset file conversions. Built with Go and Wails v3, it wraps command-line tools (retoc.exe and UAssetBridge) into a user-friendly interface.

The toolkit is organized as a collection of modding tools where the main `ARI-S` subdirectory contains the GUI application.

## Architecture

### Backend (Go)

The application is built with **Wails v3** (alpha.36) and Go 1.24+. The backend follows a service-oriented architecture:

- **App** (`app.go`): Main application struct handling lifecycle, configuration management, and Windows folder dialogs via syscall APIs
- **RetocService** (`retoc.go`): Wraps retoc.exe for packing/unpacking IoStore containers (.utoc/.ucas/.pak files)
- **UAssetService** (`uasset.go`): Interfaces with UAssetBridge for .uasset/.uexp ↔ JSON conversions
- **Config** (`config.go`): JSON-based configuration stored at `%USERPROFILE%\AppData\Local\TINK.R_Toolkit\config.json`

All services are registered in `main.go` using Wails' service system.

### Frontend (Vanilla JS)

Located in `ARI-S/frontend/`:
- **index.html**: Single-page application with sidebar navigation
- **main.js**: JavaScript with Wails Go bindings (auto-generated in `bindings/`)
- **public/style.css**: Dark/light theme with dynamic gradients

The frontend uses Vite for bundling (configured via Wails). Built assets go to `frontend/dist/` and are embedded into the Go binary.

### External Tools Integration

- **Retoc** (source: `Resources/retoc/` directory): CLI for Unreal Engine IoStore operations (to-zen, to-legacy, unpack)
  - Requires `oo2core_9_win64.dll` in the same directory
  - Looked up at runtime relative to the executable: `<exe_dir>/retoc/retoc.exe`

- **UAssetBridge** (`ARI-S/UAssetBridge/`): .NET 9 console application for UAsset/JSON conversion
  - Currently a placeholder implementation - full UAssetAPI integration needed
  - Built to `ARI-S/build/` directory

## Development Commands

### Initial Setup
```bash
cd "G:\Grounded\Modding\TINKR Toolkit\ARI-S"
go mod tidy
cd frontend
npm install
```

### Development Mode
```bash
# Run with hot reload
cd "G:\Grounded\Modding\TINKR Toolkit\ARI-S"
wails3 dev

# Alternative using Task
task dev
```

### Building

**Full Build (recommended):**
```bash
# From ARI-S directory
build.bat
```
This script:
1. Builds UAssetBridge: `dotnet publish -c Release -r win-x64 --self-contained true -o build/`
2. Copies retoc files from `../Resources/retoc/` to `build/`
3. Runs `wails build`

**Wails Build Only:**
```bash
wails build
# or
task build
```

**Output:** `bin/ARI-S.exe`

### Testing UAssetBridge Standalone
```bash
cd "G:\Grounded\Modding\TINKR Toolkit\ARI-S\UAssetBridge\UAssetBridge"
dotnet run -- export "path\to\folder"
dotnet run -- import "path\to\folder"
```

## Key Implementation Details

### Retoc Integration
The RetocService constructs commands based on operation type:
- **to-zen**: `retoc.exe to-zen --version UE5_4 "input" "output.utoc"`
- **to-legacy**: `retoc.exe to-legacy "input.pak" "output"`
- **unpack**: `retoc.exe unpack "input.pak" "output"`

Retoc always appends `_P` suffix to mod names for pak priority (handled in retoc.go:184-234 renameOutputFiles).

### Configuration Persistence
Config is loaded on startup (`WailsInit`) and saved on shutdown (`WailsShutdown`). The config stores:
- Last used paths for all input fields (keyed by field name)
- Preferences (UE version, theme)
- Tool paths (retoc.exe, uasset_bridge.exe)

### Windows Folder Dialog
`app.go:90-178` implements native Windows folder picker using `shell32.dll` syscalls (`SHBrowseForFolderW`, `SHGetPathFromIDListW`).

### UAsset Bridge Placeholder
The current C# implementation (Program.cs) is a placeholder. It creates dummy JSON files but doesn't actually parse .uasset files. Full integration requires building UAssetAPI from source (https://github.com/atenfyr/UAssetAPI).

## File Structure

```
TINKR Toolkit/
├── Resources/                   # External tools and resources
│   ├── Assets/                 # Branding assets
│   ├── retoc/                  # Retoc executable and DLL
│   │   ├── retoc.exe
│   │   └── oo2core_9_win64.dll
│   ├── UE4SS/                  # UE4SS source code (C++)
│   ├── UAssetAPI/              # UAssetAPI library
│   ├── UAssetGUI/              # UAsset GUI tool
│   ├── FModel/                 # FModel asset explorer
│   └── Resources.txt           # Resource documentation
├── ARI-S/                      # Main application
│   ├── frontend/
│   │   ├── index.html          # UI layout with sidebar navigation
│   │   ├── main.js             # Frontend logic and Wails bindings
│   │   ├── public/style.css    # Dark/light theme styles
│   │   ├── bindings/           # Auto-generated Go→JS bindings
│   │   └── dist/               # Build output (embedded into Go binary)
│   ├── UAssetBridge/
│   │   └── UAssetBridge/
│   │       ├── Program.cs      # Placeholder JSON export/import
│   │       └── UAssetBridge.csproj  # .NET 9 project
│   ├── build/                  # Build artifacts
│   │   ├── retoc.exe           # Copied here during build
│   │   ├── oo2core_9_win64.dll
│   │   └── UAssetBridge.exe
│   ├── bin/                    # Final executable output
│   ├── app.go                  # Main app service
│   ├── config.go               # Configuration management
│   ├── retoc.go                # Retoc service
│   ├── uasset.go               # UAsset service
│   ├── main.go                 # Entry point
│   ├── build.bat               # Comprehensive build script
│   └── Taskfile.yml            # Task runner config
├── SDK/                        # Symlink to Grounded 2 C++ SDK
├── GameFiles/                  # Symlink to extracted game files
└── Mods/                       # Symlink to UE4SS mods folder
```

## UI Design Philosophy

- **Compact Layout**: Designed for smaller windows without maximization
- **Dynamic Gradients**: "Gamer" aesthetic with blue/gray/black palette
- **Theme Switching**: Dark (default) and light modes with persistence
- **Always-Visible Console**: Output console is always shown for operations
- **Auto-Priority**: Priority suffix (`_P`) is always appended to mod paks

## Common Development Tasks

### Adding a New Tool Service

1. Create new service file (e.g., `newtool.go`):
```go
package main

type NewToolService struct {
    app *App
}

func NewNewToolService(app *App) *NewToolService {
    return &NewToolService{app: app}
}

// Add exported methods callable from frontend
func (n *NewToolService) RunTool(ctx context.Context, args ToolArgs) ToolResult {
    // Implementation
}
```

2. Register in `main.go`:
```go
Services: []application.Service{
    application.NewService(app),
    application.NewService(NewRetocService(app)),
    application.NewService(NewUAssetService(app)),
    application.NewService(NewNewToolService(app)),  // Add this
},
```

3. Add frontend pane in `index.html` and wire up in `main.js`

### Modifying Retoc Commands

Retoc command construction happens in `retoc.go:42-128`. Arguments are built as string slices and passed to `exec.CommandContext`. The working directory is always set to retoc's directory to ensure `oo2core_9_win64.dll` is found.

### Updating UAssetBridge

The placeholder implementation is in `UAssetBridge/UAssetBridge/Program.cs`. To add real UAssetAPI integration:
1. Add UAssetAPI NuGet package or build from source
2. Replace placeholder logic in `ExportUAssets` and `ImportUAssets`
3. Rebuild: `dotnet publish -c Release -r win-x64 --self-contained true`

## Known Limitations

- UAssetBridge is currently a placeholder (creates dummy JSON files)
- No file browser dialog integration from Wails (uses Windows syscalls instead)
- Retoc must be in `retoc/` directory relative to executable
- Windows-only (uses Windows-specific syscalls for folder dialogs)

## Important Paths

- **Config**: `%USERPROFILE%\AppData\Local\ARI-S\config.json`
- **Retoc Runtime**: `<executable_dir>/retoc/retoc.exe`
- **UAssetBridge**: `<executable_dir>/build/UAssetBridge.exe` (configurable in settings)

## External Resources

- UAssetAPI: https://github.com/atenfyr/UAssetAPI
- UAssetAPI Build Guide: https://atenfyr.github.io/UAssetAPI/guide/build.html
- Retoc: https://github.com/trumank/retoc
- Wails v3 Docs: https://v3alpha.wails.io/

## Branding

The toolkit is branded as "ARI.S" (Asset Reconfiguration and Integration System) developed by researchers at Ominent Technologies' Practical Applications Division. Assets are in `Resources/Assets/` directory, ready for integration.

## Deep-Scan and Verification Policy

When performing any project-wide edit, audit, rename, or verification task, you must:
- Read and process **every line** of each relevant file in full.
- **Do not sample or infer** file completeness from partial reads (e.g., reading the first 100 lines).
- If a file exceeds token limits, **chunk and sequentially process** the full file until complete.
- Always verify that all referenced paths, names, and variables are consistent across the entire codebase.
- Never skip large files due to size; handle them in multiple passes if necessary.
- **Report when files are verified complete** - explicitly note "verified all N lines" in your summary.

This rule applies to all operations that use phrasing such as:
"check every file," "update across the project," "verify all references," "audit documentation," or "rename the entire project."

The goal is accuracy and consistency, not speed or token efficiency.
