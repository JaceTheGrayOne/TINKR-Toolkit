# Project Identity Specification (Delta)

## ADDED Requirements

### Requirement: Module Naming
The Go module SHALL use a proper project name instead of placeholder values.

#### Scenario: Go module uses project name
- **WHEN** go.mod is read
- **THEN** the module name is "aris"
- **AND** the module name is not "changeme"
- **AND** all Go imports reference the correct module name

#### Scenario: Wails bindings match module name
- **WHEN** Wails generates frontend bindings
- **THEN** bindings are generated in frontend/bindings/aris/ directory
- **AND** no bindings/changeme/ directory exists
- **AND** frontend can successfully import from "./bindings/aris"

#### Scenario: Module name change does not break builds
- **WHEN** module name is updated from "changeme" to "aris"
- **THEN** `go mod tidy` succeeds without errors
- **AND** `wails3 dev` regenerates bindings successfully
- **AND** application compiles and runs
- **AND** no import errors occur

### Requirement: Branding Consistency
Project documentation and code comments SHALL use consistent naming that reflects the current project identity.

#### Scenario: No references to old project names
- **WHEN** code is searched for "TINK.R Toolkit"
- **THEN** no results are found in active code or comments
- **AND** all references use "ARI-S" or "ARI.S" as appropriate

#### Scenario: Display name vs system name consistency
- **WHEN** project identity is referenced in documentation
- **THEN** "ARI.S" (with period) is used for user-facing display text
- **AND** "ARI-S" (with hyphen) is used for file paths and system identifiers
- **AND** the distinction is clearly documented

#### Scenario: Configuration paths reference correct project
- **WHEN** comments describe configuration file locations
- **THEN** comments mention "ARI-S" directory names
- **AND** no stale "TINK.R Toolkit" references exist
- **AND** path descriptions match actual implementation
