# OpenSpec Usage Guide for TINKR Toolkit

This guide explains how to work with Claude Code using the OpenSpec workflow in this project.

## OpenSpec Workflow Overview

OpenSpec is a **spec-driven development system** with three distinct stages:

### **Stage 1: Creating Changes (Proposals)**
When you want to add features, make breaking changes, or modify architecture, we create a **change proposal** before writing code.

**When to create proposals:**
- New features or functionality
- Breaking changes (API, schema, architecture)
- Performance optimizations that change behavior
- Security pattern updates

**When NOT to create proposals (just fix directly):**
- Bug fixes (restoring intended behavior)
- Typos, formatting, comments
- Non-breaking dependency updates
- Configuration tweaks
- Tests for existing behavior

**The workflow:**
1. **Explore context**: Claude runs `openspec list` and `openspec list --specs` to understand current state
2. **Choose a unique ID**: kebab-case, verb-led (e.g., `add-retoc-validation`, `update-theme-system`)
3. **Create directory structure**: `openspec/changes/<change-id>/`
4. **Write 3-4 files**:
   - **`proposal.md`**: Why (problem), What (changes), Impact (affected code/specs)
   - **`tasks.md`**: Implementation checklist with `- [ ]` items
   - **`specs/<capability>/spec.md`**: Delta changes using `## ADDED/MODIFIED/REMOVED Requirements`
   - **`design.md`** (optional): Only if there's architectural complexity, cross-cutting changes, or new dependencies
5. **Validate**: Run `openspec validate <change-id> --strict` to ensure proper formatting
6. **Request approval**: Claude presents the proposal and waits for your approval before implementing

### **Stage 2: Implementing Changes**
After you approve the proposal, Claude implements it step-by-step:

1. **Read proposal.md** - Understand what we're building
2. **Read design.md** (if exists) - Review technical decisions
3. **Read tasks.md** - Get the implementation checklist
4. **Implement tasks sequentially** - Complete in order, using TodoWrite to track progress
5. **Update checklist** - After ALL work is done, mark tasks as `- [x]` in `tasks.md`
6. **Confirm completion** - Ensure everything in `tasks.md` is finished

**Important**: Claude won't start implementation until you explicitly approve the proposal.

### **Stage 3: Archiving Changes**
After you deploy/confirm the feature works, we archive the change:

1. Move `changes/<name>/` → `changes/archive/YYYY-MM-DD-<name>/`
2. Update `specs/` with the final requirements (merge deltas into permanent specs)
3. Run `openspec validate --strict` to confirm everything is clean
4. Command: `openspec archive <change> --yes` (or use `--skip-specs` for tooling-only changes)

---

## How We Work Together

### **Your Role:**
- **Initiate changes**: Tell Claude what feature/improvement you want
- **Approve proposals**: Review the proposal before Claude starts coding
- **Test results**: Verify the implementation works as expected
- **Decide on archiving**: Tell Claude when a change is ready to archive

### **Claude's Role:**
- **Create proposals**: Draft well-structured change proposals with clear requirements
- **Validate early**: Run `openspec validate --strict` before showing you the proposal
- **Track progress**: Use TodoWrite during implementation to keep you informed
- **Ask clarifying questions**: If your request is ambiguous, Claude will ask 1-2 questions before creating the proposal
- **Update documentation**: Keep CLAUDE.md and project.md in sync with changes

---

## Practical Examples

### **Example 1: You want a new feature**

**You say**: "I want to add a file browser dialog using native Windows APIs"

**Claude does**:
1. Run `openspec list` and `openspec list --specs` to check for conflicts
2. Ask clarifying questions if needed (e.g., "Should this replace the current folder dialog or work alongside it?")
3. Create proposal: `add-native-file-dialog`
4. Write `proposal.md`, `tasks.md`, and `specs/file-selection/spec.md`
5. Run `openspec validate add-native-file-dialog --strict`
6. Present the proposal to you with: "I've created a proposal for adding native file dialogs. Please review before I start implementation."

**You do**:
- Review the proposal
- Approve it or request changes

**Claude does**:
- Implement the tasks sequentially
- Mark tasks complete in `tasks.md`
- Let you know when done

### **Example 2: You find a bug**

**You say**: "The retoc path isn't being saved to config"

**Claude does**:
- **Skip proposal** (it's a bug fix, not a new capability)
- Fix the bug directly in `config.go`
- Test that it works
- Explain what was broken and how it was fixed

### **Example 3: You want to improve existing functionality**

**You say**: "Can we make the UAsset export show a progress bar instead of just console output?"

**Claude does**:
1. Check if there's an existing spec for `uasset-export`
2. Create proposal: `update-uasset-progress-ui`
3. Write `specs/uasset-export/spec.md` with `## MODIFIED Requirements` (full requirement text, not just the changes)
4. Include scenarios for progress bar behavior
5. Get your approval, then implement

---

## Key Commands Claude Uses

```bash
# Exploring current state
openspec list                     # Show active changes
openspec list --specs             # Show existing capabilities
openspec show <change-id>         # View proposal details

# Validating proposals
openspec validate <change-id> --strict

# Debugging (if needed)
openspec show <change-id> --json --deltas-only

# After deployment
openspec archive <change-id> --yes
```

---

## Critical Formatting Rules

### **Scenarios must use 4 hashtags:**
```markdown
#### Scenario: User clicks export button
- **WHEN** user selects a folder
- **THEN** the export begins
```

### **Requirements use SHALL/MUST:**
```markdown
### Requirement: Export Progress
The system SHALL display a progress bar during export operations.
```

### **Every requirement needs at least one scenario**

### **Delta operations:**
- `## ADDED Requirements` - New capabilities
- `## MODIFIED Requirements` - Changed behavior (paste FULL requirement, not just changes)
- `## REMOVED Requirements` - Deprecated features
- `## RENAMED Requirements` - Name changes only

---

## What This Means for You

### **More structured workflow:**
- You'll see proposals before implementation
- Clear task lists so you know what's being built
- Requirements captured for future reference

### **Better communication:**
- Proposals help us align on what's being built
- Scenarios serve as acceptance criteria
- You can request changes before code is written

### **Long-term benefits:**
- `openspec/specs/` becomes your single source of truth
- Archived changes show the evolution of the toolkit
- New contributors (or future AI assistants) can read specs to understand capabilities

---

## Simple Rule of Thumb

**If you say "I want..." or "Can we add..." → Claude creates a proposal**
**If you say "This is broken..." → Claude fixes it directly**

---

## Directory Structure

```
openspec/
├── project.md              # Project conventions and tech stack
├── AGENTS.md               # Detailed instructions for AI assistants
├── specs/                  # Current truth - what IS built
│   └── [capability]/
│       ├── spec.md         # Requirements and scenarios
│       └── design.md       # Technical patterns (optional)
├── changes/                # Proposals - what SHOULD change
│   ├── [change-name]/
│   │   ├── proposal.md     # Why, what, impact
│   │   ├── tasks.md        # Implementation checklist
│   │   ├── design.md       # Technical decisions (optional)
│   │   └── specs/          # Delta changes
│   │       └── [capability]/
│   │           └── spec.md # ADDED/MODIFIED/REMOVED
│   └── archive/            # Completed changes
```

---

## Quick Reference

### **Stage Indicators**
- `changes/` - Proposed, not yet built
- `specs/` - Built and deployed
- `archive/` - Completed changes

### **File Purposes**
- `proposal.md` - Why and what
- `tasks.md` - Implementation steps
- `design.md` - Technical decisions (optional)
- `spec.md` - Requirements and behavior

### **Approval Gates**
- ✅ Proposal must be approved before implementation starts
- ✅ All tasks must be complete before archiving
- ✅ Validation must pass before considering proposal ready

---

## OpenSpec AI Collaboration Notes

When working with OpenSpec files (proposals, specs, or any files in `openspec/`), follow the **Deep-Scan and Verification Policy** defined in CLAUDE.md.

This requires reading every line of all relevant files - no partial scans or inferred completions. OpenSpec modifications demand complete accuracy to maintain spec integrity.
