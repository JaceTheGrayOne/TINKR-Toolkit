import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { Retoc } from './components/Retoc';
import { UAssetAPI } from './components/UAssetAPI';
import { Settings } from './components/Settings';
import { Sidebar } from './components/Sidebar';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'retoc' | 'uassetapi' | 'settings'>('dashboard');

  return (
    <div className="flex h-screen bg-[#0a0a0a] text-white overflow-hidden">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="flex-1 overflow-auto">
        {currentPage === 'dashboard' && <Dashboard onNavigate={setCurrentPage} />}
        {currentPage === 'retoc' && <Retoc />}
        {currentPage === 'uassetapi' && <UAssetAPI />}
        {currentPage === 'settings' && <Settings />}
      </main>
    </div>
  );
}
